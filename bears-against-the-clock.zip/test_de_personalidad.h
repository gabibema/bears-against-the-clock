#ifndef __TEST_DE_PERSONALIDAD_H__
#define __TEST_DE_PERSONALIDAD_H__


/*
 * PRE:
 * POS: 
 */ 

void test_de_personalidad(char* personalidad_detectada);


#endif /* __TEST_DE_PERSONALIDAD  */ 